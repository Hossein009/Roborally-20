package dk.dtu.compute.se.pisd.roborally.fileaccess.model;


public class CommandTemplate {
    public String type;

}

