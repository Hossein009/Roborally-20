package dk.dtu.compute.se.pisd.roborally.fileaccess.model;

public class CommandCardFieldTemplate {

    public CommandCardTemplate card;
    public boolean visible;
}
