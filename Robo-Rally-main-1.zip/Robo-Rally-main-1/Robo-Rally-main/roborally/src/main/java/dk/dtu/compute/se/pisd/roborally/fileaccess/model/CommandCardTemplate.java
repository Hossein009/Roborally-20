package dk.dtu.compute.se.pisd.roborally.fileaccess.model;


public class CommandCardTemplate {
    public CommandTemplate command;
}
