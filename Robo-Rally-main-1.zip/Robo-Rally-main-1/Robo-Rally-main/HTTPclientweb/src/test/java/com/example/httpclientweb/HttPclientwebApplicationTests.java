package com.example.httpclientweb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HttPclientwebApplicationTests {

    @Test
    void contextLoads() {
    }

}
