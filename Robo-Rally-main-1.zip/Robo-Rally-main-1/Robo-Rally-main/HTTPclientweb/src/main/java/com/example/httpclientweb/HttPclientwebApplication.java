package com.example.httpclientweb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HttPclientwebApplication {

    public static void main(String[] args) {
        SpringApplication.run(HttPclientwebApplication.class, args);
    }

}
